package com.startup.template.domain.model

data class PassportFormatD(
    val nationality: String,
    val format: String,
    val example: String
)




