package com.startup.template.presentation.details

import androidx.lifecycle.ViewModel
import javax.inject.Inject

class DetailScreenViewModel @Inject constructor() : ViewModel() {
    init {
        println("init started of details")
    }


}